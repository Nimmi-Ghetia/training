var express = require('express');
// var bodyParser = require('body-parser');
var app = express(); // the main app
var routes = require('./routes.js');



app.set('view engine', 'pug');
app.set('views', './views');
// var admin = express(); // the sub app
// app.use(bodyParser.json());
app.use('/', routes);
app.use(express.static('./public'));


// app.all('/', function (req, res, next) {
//     console.log('Accessing the secret section ...')
//     next() // pass control to the next handler
// });


// app.get('/', function (req, res) {
//     console.log(app.mountpath); // /app
//     console.log('baseurl' + req.baseUrl);
//     console.log(req.hostname);
//     // res.json(req.body);
//     res.send('hello world');
// });


// app.post('/hello', function (req, res) {
//     res.send("You just called the post method at '/hello'!\n");
// });

// app.delete('/', function (req, res) {
//     res.send('DELETE request to homepage');
// });


// var secret = express();
// secret.get('/', function (req, res) {
//   console.log(secret.mountpath); // /secr*t
//   res.send('Admin Secret');
// });

// admin.get('/', function (req, res) {
//     console.log(admin.mountpath); // /admin
//     console.log('baseurl'+req.url);
//     res.send('Admin Homepage');
// });

// app.use(['/admin','/manager'], admin); // mount the sub app.
// admin.use('/secret',secret);
app.listen(3000);