var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/user-data');
const winston = require('winston');


var userSchema = mongoose.Schema({
    userId: Number,
    userName: String,
    email: String,
    dt: String,
    designation: String,
    contactNo: Number,
    address: String,
    password: String
});
var User = mongoose.model("user", userSchema);

module.exports.getusers = function () {

    return User.find();
}

module.exports.get = function (uId) {

    return User.findOne({ "userId": uId });
}

module.exports.post = function (body) {
    var userInfo = body; //Get the parsed information
    var newUser = new User(body);
    return newUser.save();

}

module.exports.put = function (uid, body) {
    return User.findOneAndUpdate({ "userId": uid }, body);

}

module.exports.delete = function (uid) {
    return User.findOneAndRemove({ "userId": uid });

}