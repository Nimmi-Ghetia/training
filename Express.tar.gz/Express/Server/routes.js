var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/user-data');

var userSchema = mongoose.Schema({
    userId: Number,
    userName: String,
    email: String,
    dt: String,
    designation: String,
    contactNo: Number,
    address: String,
    password: String
});
var User = mongoose.model("user", userSchema);

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

//Middleware function to log request protocol
router.use('/', function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', false);
    console.log("A request received at " + Date.now());
    next();
});

router.get('/user', function (req, res) {
    User.find(function (err, response) {
        res.json(response);
    });
});
router.post('/user', function (req, res) {
    var userInfo = req.body; //Get the parsed information

    if (false) {
        res.render('show_message', {
            message: "Sorry, you provided worng info", type: "error"
        });
    } else {
        var newUser = new User({
            userId: userInfo.userId,
            userName: userInfo.userName,
            email: userInfo.email,
            dt: userInfo.dt,
            designation: userInfo.designation,
            contactNo: userInfo.contactNo,
            address: userInfo.address,
            password: userInfo.password
        });

        newUser.save(function (err, User) {
            if (err)
                res.json({ message: "Database error", type: "error" });
            else
                res.json( {
                    message: "New User added", type: "success", User: userInfo
                });
        });
    }
});

router.get('/user/:userId', function (req, res) {
    let uId=req.params.userId;
    // console.log(userId);
    User.findOne({"userId" : uId}, req.body, function (err, response) {
        if (err) res.json({ message: "Error in updating User with id " + req.params.userId +err});
        // console.log(req.body);
        res.json(response);
    });
})

router.put('/user/:userId', function (req, res) {
    let uId=req.params.userId;
    // console.log(userId);
    User.findOneAndUpdate({"userId" : uId}, req.body, function (err, response) {
        if (err) res.json({ message: "Error in updating User with id " + req.params.userId +err});
        // console.log(req.body);
        res.json(response);
    });
})

router.delete('/user/:userId', function (req, res) {
    let uId=req.params.userId;
    User.findOneAndRemove({"userId" : uId}, function (err, response) {
        if (err) res.json({ message: "Error in deleting record id " + req.params.userId });
        else res.json({ message: "User with id " + req.params.userId + " removed." });
    });
});

router.get('*', function (req, res) {
    res.send('Sorry, this is an invalid URL.');
});
//export this router to use in our index.js
module.exports = router;