angular.module("validateForm")
    .component("validateForm",{
       templateUrl:"validation/wongmsg/form.html",
       controller:
           function (){
            console.log("in validate form controller");
           }



    });
