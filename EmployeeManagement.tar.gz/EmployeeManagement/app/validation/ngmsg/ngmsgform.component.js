angular.module("ngmsgForm")
.component("ngmsgForm",{
    templateUrl:"validation/ngmsg/ngmsgform.html",
    controller:
        function(){
            console.log("ng msg controller");
        }

    }

);
