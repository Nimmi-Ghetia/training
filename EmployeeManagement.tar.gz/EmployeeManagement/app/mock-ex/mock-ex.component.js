angular.module("mockExample")
    .component("mockExample", {
            templateUrl:"mock-ex/mock-ex.template.html",
            // template:'Hello',
            controller: ["$http",
                function ($http) {
                console.log('in controller');
                    var self = this;
                    self.phones = [];
                    self.newphone = {name: ''};
                    self.getPhones = function () {
                        $http.get('/phones').then(function (response) {
                            self.phones=response.data ;
                            console.log(self.phones+'phones');
                        });
                    };
                    self.addPhone=function () {
                        self.newphone={name:''};
                            return self.getPhones();
                    };
                }

            ]

        }
    );