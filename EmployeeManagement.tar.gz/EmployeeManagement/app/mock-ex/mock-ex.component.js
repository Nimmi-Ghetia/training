angular.module("mockExample")
    .component("mockExample", {
            templateUrl:'/mock-ex/mock-ex.template.html',

            controller: ['$http'
                function ($http) {
                    var self = this;
                    self.phones = [];
                    self.newphone = {
                        name: ''
                    };
                    self.getPhones = function () {
                        $http.get('/phones').then(function (response) {
                            self.phones=response.data ;
                        })
                    }
                    self.addPhone=function () {
                        self.newphone={name:''};
                            return self.getPhones();
                    }

                }

            ]

        }
    );