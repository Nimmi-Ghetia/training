(function (angular) {
    'use strict';
    var myAppDev = angular.module('myE2Emock', ['myApp', 'ngMockE2E']);

    myAppDev.run(function ($httpBackend) {
        $httpBackend.whenGET(/.html/).passThrough();
        // $httpBackend.whenGET(/.html/).passThrough();
        var users = [{"userId":"213","userName":"dfsf","email":"m@gmail.com","dt":"1984-06-06T18:30:00.000Z","designation":"BA","contactNo":4324213134,"address":"3424dfffffffffff","password":"123","confirmPassword":"123"}
            , {userId: 923, userName: 'SBC', email: 'tanu@gmail.com',dt:new Date(1998,2,1),designation:'BA', contactNo: 8234567980, address: 'zfbgfbvf'},
            {userId: 823, userName: 'NBC', email: 'hanu@gmail.com',dt:new Date(1998,2,1),designation:'BA',    contactNo: 4234567980, address: 'gfbgfbvf'}];

        // returns the current list of phones
        $httpBackend.whenGET('/user').respond(users);

        // Get; return a single contact.
        $httpBackend.whenGET(/\/user\/(\w+)/, undefined, ['id'])
            .respond(function (method, url, data, headers, params) {
                console.log('get');
                var user = findUserById(params.id);
                if (user == null) {
                    return [404, undefined, {}];
                }
                console.log('User : ');
                console.log(user);
                return [200, user, {}];
            });


        function findUserById(id) {
            // Convert id to a number.
            var userid = id;
            var matches = users.filter(function (user) {
                return user.userId === userid;
            });
            var user = matches.shift();
            return user;
        }

        // adds a new phone to the phones array
        $httpBackend.whenPOST('/user').respond(function (method, url, data) {
            var user = angular.fromJson(data);
            users.push(user);
            return [200, user, {}];
        });

        // Update; change details for an existing contact.
        $httpBackend.whenPUT(/\/user\/(\d+)/, undefined, undefined, ['id']).respond(function (method, url, data, headers, params) {
            var user = findUserById(params.id),
                parsedData = angular.fromJson(data);
            if (user == null) {
                return [404, undefined, {}];
            }
            angular.extend(user, parsedData);
            return [200, user, {}];
        });

        $httpBackend.whenDELETE(/\/user\/(\w+)/, undefined, ['id']).respond(function (method, url, data, headers, params) {
            var user = findUserById(params.id);
            if (user == null) {
                return [404, undefined, {}];
            }
            users.splice(users.indexOf(user), 1);
            return [200, undefined, {}];
        });

    });
})(window.angular);
