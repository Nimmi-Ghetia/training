angular.module("myE2Emock",['mockExample','ngMockE2E'])
.run(
    function ($httpBackend) {
        var phones=[{name:'phone1'},{name:'phone2'}];
        $httpBackend.whenGET('/phones').respond(phones);
        $httpBackend.whenPOST('/phones').respond(
            function (method,url,data) {
                var phone=angular.fromJson(data);
                phones.push(phone);
                return [200,phone,{}];
            }
        );
    }
);