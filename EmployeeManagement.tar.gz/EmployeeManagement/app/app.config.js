angular.module('myApp').
config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
    $locationProvider.hashPrefix('!');
    console.log("he");
    $routeProvider
        .when('/form',{
            template: '<form-component></form-component>'
    }).when('/user-list/user',{
        template:'<user-list></user-list>',
        controller:function () {
            console.log("controller");
        }
        }

    )
        .when('/test/mock',{
        template:'<mock-example></mock-example>'
        }

    )
        .otherwise('/user-list/user');
}]);
