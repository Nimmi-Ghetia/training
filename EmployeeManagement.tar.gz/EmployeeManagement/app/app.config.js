angular.module('myApp').
config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
    $locationProvider.hashPrefix('!');
    console.log("he");
    $routeProvider
        .when('/form',{
            template: '<form-component></form-component>'
    }).when('/user-list/user',{
        template:'<user-list></user-list>',
        controller:function () {
            console.log("controller");
        }
        }

    ).when('/validate/form',{
        template:'<validate-form></validate-form>'
        }

    ).when('/validate/form2',{
            template:'<ngmsg-form></ngmsg-form>'
    }).when('/test/mock',{
        template:'<mock-example></mock-example>'
        }

    )
        .otherwise('/test/mock');
}]);
