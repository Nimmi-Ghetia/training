angular.module('core.user').
filter('formatDate', function () {
    return function (string) {
        var date = new Date(string);

        if (date.getDate() < 10)
            fdate = '0' + date.getDate();
        else
            fdate = date.getDate();

        if (date.getMonth() < 10)
            fmonth = '0' + (date.getMonth()+1);
        else
            fmonth = (date.getMonth()+1);

        return fdate + '-' + fmonth + '-' + date.getYear();
    };
})