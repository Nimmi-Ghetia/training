angular.
    module('core.user').
    factory('User',['$resource',
    function ($resource) {
        console.log('get all');
        return $resource('/user/:userId',{},{
            query:{
                method:'GET',
                params:{userId:''},
                isArray: true
            },
            'update':{
                method:'PUT'
            }
        }
        );
    }

    ]
);