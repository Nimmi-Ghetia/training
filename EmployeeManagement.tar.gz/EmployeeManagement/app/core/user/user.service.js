angular.
    module('core.user').
    factory('User',['$resource',
    function ($resource) {
        return $resource('/user/:userId.json',{},{
            query:{
                method:'GET',
                params:{userId:'user'},
                isArray: true
            }
        }

        )
    }

    ]
);