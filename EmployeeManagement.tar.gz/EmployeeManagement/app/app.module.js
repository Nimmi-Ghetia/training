
// Declare app level module which depends on views, and components
angular.module('myApp', [
  'ngRoute',
  'ngMessages',
  'ngMockE2E',
  'formModule',
  'myApp.version',
    'userList',
    'core',
    'core.user',
    'validateForm',
      'ngmsgForm',
    'mockExample',
    'myE2Emock'
]);