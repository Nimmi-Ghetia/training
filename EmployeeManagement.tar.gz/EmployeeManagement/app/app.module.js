
// Declare app level module which depends on views, and components
angular.module('myApp', [
  'ngRoute',
  'ngMessages',
  'formModule',
  'myApp.version',
    'userList',
    'core',
    'core.user',
    'validateForm',
      'ngmsgForm',
]);