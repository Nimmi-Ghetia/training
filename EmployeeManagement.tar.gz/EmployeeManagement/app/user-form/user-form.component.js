angular.module('formModule').component("formComponent", {
    templateUrl: "user-form/user-form.template.html",
    controller: ['$window',function ($window) {

        var self = this;

        self.designations=['Developer','BA','QA'];

        this.submitForm = function () {
            console.log("after submit");
            console.log(self.userForm);
            // self.userForm.userId.$setValidity('required',false);
            // self.userForm.$invalid=true;
            console.log(self.userForm.$valid);
            if(self.userForm.$valid)
            {
                console.log("inside");
                $window.location.href='#!/user-list/user';
            }
        }

        self.validatePassword = function () {
            self.check = self.user.password != self.user.confirmPassword;
            self.userForm.password.$setValidity('required',!self.check);
            console.log(self.user);
        }

        var mydate = new Date();
        var year = new Date().getFullYear();
        year = year - 18;
        mydate.setFullYear(year);
        console.log(mydate);
        this.dateOptions = {
            datepickerMode:'month',
            maxDate: mydate,
            startingDay: 1,
            initDate: mydate,
            startView: 2
        };

        this.format = 'dd-MMMM-yyyy';

        this.open1 = function () {
            self.opened = true;
        }


    }]

});