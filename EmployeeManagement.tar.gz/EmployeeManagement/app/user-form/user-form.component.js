angular.module('formModule').component("formComponent", {
    templateUrl: "user-form/user-form.template.html",
    controller: ['$window', 'User', '$location','$filter', function ($window, User, $location,$filter) {

        var self = this;

        self.myid = $location.search().id;
        console.log('njhjnjk' + self.myid);
        if (self.myid) {
            console.log("yes"+self.myid);
            self.user = User.get({userId: self.myid});
            console.log("usr");
            console.log(self.user);
        }

        self.designations = ['Developer', 'BA', 'QA'];

        this.submitForm = function () {
            console.log("after submit");
            console.log(self.userForm);
            var userInfo = new User(self.user);
            if (self.myid) {
                console.log("myidfddsfdsfdesefedfe\n\n\n" + self.myid);
                User.update({userId: self.myid}, self.user).$promise
                    .then(
                        this.users = User.query()
                    );
            }
            else {
                userInfo.$save();
            }

            if (self.userForm.$valid) {
                console.log("inside");
                $window.location.href = '#!/user-list/user';
            }
        };

        self.validatePassword = function () {
            self.check = self.user.password != self.user.confirmPassword;
            self.userForm.password.$setValidity('required', !self.check);
        };

        // self.dt=$filter('date')(self.dt,"dd-MM-yyyy");
        // console.log("date="+self.dt);
         if(!self.myid)
        {
            var mydate = new Date();
            var year = new Date().getFullYear();
            year = year - 18;
            mydate.setFullYear(year);
            console.log(mydate);
            this.dateOptions = {
                datepickerMode: 'year',
                maxDate: mydate,
                startingDay: 1,
                initDate: mydate,
                startView: 2
            };

            this.format = 'dd-MM-yy';

            this.open1 = function () {
                self.opened = true;
            };

        }


    }]

});