angular.module('formModule').component("formComponent", {
    templateUrl: "user-form/user-form.template.html",
    controller: ['$window', 'User', '$location', '$filter', function ($window, User, $location, $filter) {

        var self = this;
        setTimeout(loadUsers, 1);

        self.myid = $location.search().id;
        if (self.myid) {
            self.user = User.get({userId: self.myid});
            self.user.$promise.then(function (data) {
                self.user.dt = new Date(data.dt);
            });
        }

        self.designations = ['Developer', 'BA', 'QA'];

        this.submitForm = function () {
            var userInfo = new User(self.user);
            if (self.myid) {
                User.update({userId: self.myid}, self.user).$promise
                    .then(
                        loadUsers()
                    );
            }
            else {
                userInfo.$save();
                loadUsers();
            }
            if (self.userForm.$valid) {
                $window.location.href = '#!/user-list/user';
            }
        };

        function loadUsers() {
            User.query().$promise.then(function (data) {
                self.users = data;
            });
        }

        self.validatePassword = function () {
            self.check = self.user.password != self.user.confirmPassword;
            self.userForm.password.$setValidity('required', !self.check);
        };

        if (self.myid) {
            mydate = self.user.dt;
        }
        var mydate = new Date();
        var year = new Date().getFullYear();
        year = year - 18;
        mydate.setFullYear(year);
        // self.user.dt = mydate;
        console.log(mydate);
        if (!self.myid) {
            self.user = {
                "designation": self.designations[0],
                "dt": mydate
            };
        }
        this.dateOptions = {
            datepickerMode: 'year',
            maxDate: mydate,
            startingDay: 1,
            initDate: mydate,
            startView: 2
        };

        this.format = 'dd-MM-yy';

        this.open1 = function () {
            self.opened = true;
        };


    }]

});