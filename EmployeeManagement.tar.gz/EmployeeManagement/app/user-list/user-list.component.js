angular.module("userList").component("userList",{
    templateUrl:"user-list/user-list.template.html",
    controller:["User",'$window', function (User,$window) {
        // this.userId = $routeParams.userId;


        this.sortType     = 'username'; // set the default sort type
        this.sortReverse  = false;  // set the default sort order
        this.searchFish   = '';     // set the default search/filter term
        this.getUser= function (userid) {
            console.log("hjdfjkshf");
            var myuser=User.get({userId:userid});
            console.log(myuser);

        }
        this.users=User.query();

    this.deleteUser = function (userid) {
        User.remove({userId: userid}).$promise
        .then(
            this.users = User.query()
        );
    }


        console.log(this.users);
        // var myjson={userId:0,
        //     userName: "",
        //     email:"",
        //     contactNo:0,
        //     address:"",
        //     password:"",
        //     designation:""
        // }

        // myjson.userName=document.forms["myform"]["userName"].value ;
        // console.log(this.userName);
    }]
});
