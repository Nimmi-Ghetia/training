angular.module("userList").component("userList",{
    templateUrl:"user-list/user-list.template.html",
    controller:["User", function (User) {
        // var myjson={userId:0,
        //     userName: "",
        //     email:"",
        //     contactNo:0,
        //     address:"",
        //     password:"",
        //     designation:""
        // }

        // myjson.userName=document.forms["myform"]["userName"].value ;
        // console.log(this.userName);
    }]
});
