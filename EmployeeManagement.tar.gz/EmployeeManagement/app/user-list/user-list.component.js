angular.module("userList").component("userList", {
    templateUrl: "user-list/user-list.template.html",
    controller: ["User", '$window', function (User, $window) {
        // this.userId = $routeParams.userId;
        setTimeout(loadUsers, 1);
        var self = this;
        this.sortType = 'username'; // set the default sort type
        this.sortReverse = false;  // set the default sort order
        this.searchFish = '';     // set the default search/filter term
        this.getUser = function (userid) {
            console.log("hjdfjkshf");
            var myuser = User.get({userId: userid});
            console.log(myuser);
        }
        User.query().$promise.then(function (data) {
            self.users = data;
        });

        this.deleteUser = function (userid) {
            User.remove({userId: userid}).$promise
                .then(function (data) {
                        loadUsers();
                    }
                );
        }

        function loadUsers() {
            User.query().$promise.then(function (data) {
                self.users = data;
            });
        }

        console.log(this.users);
        // var myjson={userId:0,
        //     userName: "",
        //     email:"",
        //     contactNo:0,
        //     address:"",
        //     password:"",
        //     designation:""
        // }

        // myjson.userName=document.forms["myform"]["userName"].value ;
        // console.log(this.userName);
    }]
});
